from io import BytesIO
from bs4 import BeautifulSoup
from collections import defaultdict
from urllib.request import urlopen
import csv
import sqlite3
import pandas as pd
import os
import pickle

sqliteConnection = None

def openHtmlFile(htmlfile):
    f = open(htmlfile, "r")
    contents = f.read()
    return BeautifulSoup(contents, 'html.parser')
header = []
results = []
r=[]
e = []
d = defaultdict(list)

soupf = openHtmlFile("Co2.html") #local file
arr = soupf.findAll('td')
for i in range(9,len(arr),84):
    header.append(int(arr[i].text))
    
#finding the average value per month and finding the average value for each year
for i in range(12, len(arr), 7):
    results.append(float(arr[i].text))
for j in range(0, len(results),12):
    r.append(round(sum(results[j:j+12])/12, 2))
for k in range(0, len(header)):
    e.append((header[k], r[k]))
    
#creating defaultdict d to hold the values    
for hed, res in e:
    d[hed]=res
    


dt = []
df = pd.read_csv('SeaLevel.csv', comment='#')
specific_columns=df[["year","TOPEX/Poseidon"]]
s = specific_columns.to_dict('list')
o = defaultdict(list)
p = defaultdict(list)
g= []

#finding the average value for each year by adding the values for each year and dividing by the times added
for i in range(0,len(s['year'])):
    dt.append((int(s['year'][i]),float(s['TOPEX/Poseidon'][i])))
for y, t in dt:
    o[y].append(t)
for name in o:
    n = round(sum(o[name])/len(o[name]),2)
    p[name] = n



class Database:
    def __init__(self, db, table_name, escape_hook=None):
        sqliteConnection = sqlite3.connect(db)
        self.db = sqliteConnection
        self.dbn = db
        #I found this snippet online and edited it to fit my purpose
        self._cmd_string = ''
        self._where_string = ''
        if escape_hook:
            self._fmt_params = {'table_name': escape_hook(table_name)}
        else:
            self._fmt_params = {'table_name': table_name}
    
        self._values = {'cmd': None, 'where': None}
        self.escape_hook = escape_hook
        
    def convert2Blog(self,filename):
        with open(filename, 'rb') as file:
            blobData = file.read()
        return blobData

    def connect(self):
        try:
            sqliteConnection = self.db
            cursor = sqliteConnection.cursor()
            print("Database created and Successfully Connected to SQLite")
            select_Query = "select sqlite_version();"
            print("Search query: ",select_Query)
            cursor.execute(select_Query)
            record = cursor.fetchall()
            print("SQLite Database Version is: ", record)
        except sqlite3.Error as error:
            print("Error while connecting to sqlite", error)
        
    def deleteRecord(self,id):
        try:
            sqliteConnection = self.db
            cursor = sqliteConnection.cursor()
            delete_query = "DELETE from Database where id = "+str(id)
            print("Delete query: ",delete_query)
            cursor.execute(delete_query)
            sqliteConnection.commit()
            print("Record deleted successfully ")
        except sqlite3.Error as error:
            print("Failed to delete record from sqlite table", error)

    def Search(self, value):
        sqliteConnection = self.db
        cursor = sqliteConnection.cursor()
        sel = 'SELECT id FROM Database WHERE name == "{0}"'.format(value)
        print("Search query: ",sel)
        cursor.execute(sel)
        result = cursor.fetchall()
        return result

    def insert(self, query,tup):
        sqliteConnection = self.db
        try:
            cursor = sqliteConnection.cursor()
            cursor.execute(query, tup)
            print("Search query: ",query)
            sqliteConnection.commit()
            print("Inserted successfully into table")
        except sqlite3.Error as error:
            print("Failed to insert: ", error)

    def readTable(self):
        sqliteConnection = self.db
        records = None
        try:
            cursor = sqliteConnection.cursor()
            sqlite_select_query = """SELECT * from Database"""
            print("Search query: ",sqlite_select_query)
            cursor.execute(sqlite_select_query)
            records = cursor.fetchall()
            print("Total rows are:  ", len(records))
        except sqlite3.Error as error:
            print("Failed to read data from sqlite table", error)
        return records

    def table(self,query):
        sqliteConnection = self.db
        try:
            cursor = sqliteConnection.cursor()
            cursor.execute(query)
            print("Table query: ",query)
            sqliteConnection.commit()
            print("SQLite table created")    
        except sqlite3.Error as error:
            print("Table exists: ", error)

    def update(self,id, htext):
        sqliteConnection = self.db
        try:
            cursor = sqliteConnection.cursor()
            update_query = """Update Database set html = ? where id = ?"""
            data = (htext, id)
            cursor.execute(update_query, data)
            print("Update query: ",update_query)
            sqliteConnection.commit()
            print("Record Updated successfully")
        except sqlite3.Error as error:
            print("Failed to update sqlite table", error)
    def close(self):
        sqliteConnection = self.db
        sqliteConnection.close()
        os.remove(self.dbn)     
        
    '''
    this is my query builder for inserting values,
    input: dict of column name = cmd (data ie. 24)
    returns: insert query string
    '''
    def insert_query_builder(self, **kw_attr):
        
        cols, vals = self._escape(zip(*kw_attr.items()))
        self._cmd_string = 'INSERT INTO {table_name} ({column_names}) VALUES ({param_marks})'
        self._fmt_params['column_names'] = ', '.join(cols)
        self._fmt_params['param_marks'] = ', '.join('?' for _ in range(len(cols))) 
        self._values['cmd'] = vals
        self._cmd_string = 'INSERT INTO {table_name} (ID, {column_names}) VALUES (?, {param_marks})'.format(table_name = self._fmt_params['table_name'], column_names =self._fmt_params['column_names'], param_marks =self._fmt_params['param_marks'])

        return self._cmd_string 
    '''
    this is my query builder for table, a little scuffed
    input: dict of column name = cmd (data type ie. TEXT NOT NULL)
    returns: table query string
    '''
    def table_query_builder(self, **kw_attr):
        cols, vals = self._escape(zip(*kw_attr.items()))
        self._cmd_string = 'CREATE TABLE {table_name} ({column_names, cmd})'
        self._fmt_params['column_names'] = ', '.join(cols)
        self._values['cmd'] = vals
        a = []
        b=[]
        c=[]
        for i in range(0, len(cols)):
            a.append(self._fmt_params['column_names'].split(", ")[i])
            b.append(self._values['cmd'][i])
            c.append(a[i] +" "+ b[i])
        self._cmd_string = 'CREATE TABLE {table_name} (ID INTEGER PRIMARY KEY, {r})'.format(table_name = self._fmt_params['table_name'], r= ", ".join(map(str,c))) 
        return self._cmd_string 
    
    #for the questionmars in the other thing
    def _qmarks(n):
        if hasattr(n, '__len__'):
            n = len(n)
        return ', '.join('?' for _ in range(n)) 
    
    #taking things out of the zip
    def _escape(self, colvals):
        if self.escape_hook:
            escaped = ((self.escape_hook(col), val)
                           for col, val in zip(*colvals))
            return zip(
                    *filter(lambda x: x[0] is not None, escaped)
                )
    
        return colvals   
#build database and queries, please work (UPDATE: IT WORKED YESSSSSSS, I AM SO HAPPY WORDS CANNOT DESCRIBE MY FEELINGS CURRENTLY)
dtb = Database("Lab1.db", "Database")        

tqb= dtb.table_query_builder(NAME="TEXT NOT NULL", YEAR = "TEXT NOT NULL", AVG = "TEXT NOT NULL")
dtb.table(tqb)

print(tqb)

iqb = dtb.insert_query_builder(NAME="A", YEAR = 12, AVG = 122)
print(iqb)

q=0
#now we run thru the values in each table and add it to the sql database
for i in d:
    q= q+1
    data_t = (q, "CO2",i, d[i])
    dtb.insert(iqb,data_t)
for j in p:
    q= q+1
    data_t = (q, "Sea Level",j, p[j])
    dtb.insert(iqb,data_t)
    
#read
print(dtb)
records = dtb.readTable()
#[print(r) for r in records]


#shut-down
#dtb.close()

'''
Table query:  CREATE TABLE Database (ID INTEGER PRIMARY KEY, NAME TEXT NOT NULL, YEAR TEXT NOT NULL, AVG TEXT NOT NULL)
SQLite table created
CREATE TABLE Database (ID INTEGER PRIMARY KEY, NAME TEXT NOT NULL, YEAR TEXT NOT NULL, AVG TEXT NOT NULL)
INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
Search query:  INSERT INTO Database (ID, NAME, YEAR, AVG) VALUES (?, ?, ?, ?)
Inserted successfully into table
<__main__.Database object at 0x00000207563B0E80>
Search query:  SELECT * from Database
Total rows are:   89

'''